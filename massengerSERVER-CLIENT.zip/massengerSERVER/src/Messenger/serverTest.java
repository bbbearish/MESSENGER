package Messenger;
import javax.swing.JFrame;


public class serverTest {
	public static void main(String[] args) {

		Server serv = new Server();
		serv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		serv.startRunning();	
	}
}
